function [ rows,cols ] = detect_features( image )
    %%%
	% Computer Vision 600.461/661 Assignment 2
	% Args:
	% 	image (ndarray): The input image to detect features on. Note: this is NOT the image name or image path.
	% Returns:
	% 	rows: A list of row indices of detected feature locations in the image
    % 	cols: A list of col indices of detected feature locations in the image
	%%%

end

